from Flask import session
from conexionBD import connectionBD

def dataLoginSesion():
    inforLogin = {
        "idLogin": session.get('id'),
        "tipoLogin": session.get('tipo_user'),
        "nombre": session.get('nombre'),
        "apellido": session.get('apellido'),
        "emailLogin": session.get('email'),
        "sexo": session.get('sexo'),
        "pais": session.get('pais'),
        "create_at": session.get('create_at'),
        "te_gusta_la_programacion": session.get('te_gusta_la_programacion')
    }
    return inforLogin

def listaPaises():
    try:
        conexion_MySQLdb = connectionBD()
        with conexion_MySQLdb.cursor(dictionary=True) as mycursor:
            querySQL = "SELECT * FROM countries"
            mycursor.execute(querySQL)
            paises = mycursor.fetchall()
    except Exception as e:
        # Manejar la excepción apropiadamente, puede ser un error de conexión o consulta
        print(f"Error al obtener los países: {e}")
        paises = []
    finally:
        if 'conexion_MySQLdb' in locals():
            conexion_MySQLdb.close()
    return paises

def dataPerfilUsuario():
    try:
        conexion_MySQLdb = connectionBD()
        with conexion_MySQLdb.cursor(dictionary=True) as mycursor:
            idUser = session.get('id')
            querySQL = "SELECT * FROM login_python WHERE id=%s"
            mycursor.execute(querySQL, (idUser,))
            datosUsuario = mycursor.fetchone()
    except Exception as e:
        # Manejar la excepción apropiadamente
        print(f"Error al obtener los datos del usuario: {e}")
        datosUsuario = None
    finally:
        if 'conexion_MySQLdb' in locals():
            conexion_MySQLdb.close()
    return datosUsuario
